#include "MyTeacher.h"
#include<string.h>

void MyTeacher::Set_Age(int a)
{
	m_age = a;
}
int MyTeacher::Get_Age()
{
	return m_age;
}
void MyTeacher::Set_Name(char *s)
{
	strcpy(m_name, s);
}
char* MyTeacher::Get_Name()
{
	return m_name;
}