#include "My_Cube.h"

int My_Cube::Init_ma(int a)
{
	m_a = a;
	return m_a;
}
int My_Cube::Init_mb(int b)
{
	m_b = b;
	return m_b;
}
int My_Cube::Init_mc(int c)
{
	m_c = c;
	return m_c;
}
int My_Cube::Cal_ms1()
{
	m_s1 = m_a*m_b;
	return m_s1;
}
int My_Cube::Cal_ms2()
{
	m_s2 = m_b*m_c;
	return m_s2;
}
int My_Cube::Cal_ms3()
{
	m_s3 = m_a*m_c;
	return m_s3;
}
int My_Cube::Cal_mvol()
{
	m_vol = m_a*m_b*m_c;
	return m_vol;
}
int My_Cube::Compare_Cube(My_Cube &c2)
{
	if ((m_a == c2.m_a) && (m_b == c2.m_b) && (m_c == c2.m_c))
	{
		return 1;
	}
	else
	{
		return 0;
	}
}