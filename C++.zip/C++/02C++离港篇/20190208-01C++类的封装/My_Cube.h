#pragma once
class My_Cube
{
public:
	int m_a;
	int m_b;
	int m_c;
	int m_s1;
	int m_s2;
	int m_s3;
	int m_vol;
public:
	int Init_ma(int a = 0);
	int Init_mb(int b = 0);
	int Init_mc(int c = 0);
	int Cal_ms1();
	int Cal_ms2();
	int Cal_ms3();
	int Cal_mvol();
	int Compare_Cube(My_Cube &c2);
};

