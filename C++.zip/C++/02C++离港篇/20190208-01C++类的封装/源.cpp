#include<iostream>
#include"My_Cube.h"
using namespace std;

int main()
{
	My_Cube c1, c2;
	cout << c1.Init_ma(3) << "\t" << c1.Init_mb(4) << "\t" << c1.Init_mc(5) << endl;
	cout << c2.Init_ma(3) << "\t" << c2.Init_mb(4) << "\t" << c2.Init_mc(6) << endl;
	int token = c1.Compare_Cube(c2);
	cout << token << endl;
	if (token==1)
	{
		cout << "�������" << endl;
	}
	else
	{
		cout << "���߲����" << endl;
	}
	system("pause");
	return 0;
}