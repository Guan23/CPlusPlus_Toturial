#include "Teacher.h"
#include<iostream>
using namespace std;

//Teacher::Teacher()
//{
//	m_strName = "ASDF";
//	m_strGender = "Male";
//	m_iAge = 25;
//	cout << "Teacher()" << endl;//����ģ�ֻ��Ϊ����ʾʹ���˸ù��캯��
//}

Teacher::Teacher(string name, string gender, int age)
{
	//m_strName = name;
	m_strGender = gender;
	m_iAge = age;
	cout << "Teacher(string name, string gender, int age)" << endl;//����ģ�ֻ��Ϊ����ʾʹ���˸ù��캯��
}

void Teacher::SetName(string name)
{
	//m_strName = name;
}
string Teacher::GetName()
{
	return m_strName;
}
void Teacher::SetGender(string gender)
{
	m_strGender = gender;
}
string Teacher::GetGender()
{
	return m_strGender;
}
void Teacher::SetAge(int age)
{
	m_iAge = age;
}
int Teacher::GetAge()
{
	return m_iAge;
}
void Teacher::Teach()
{
	cout << "���ڿ�ʼ�Ͽ�......" << endl;
}
