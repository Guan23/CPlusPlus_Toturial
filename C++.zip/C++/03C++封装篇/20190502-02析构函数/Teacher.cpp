#include "Teacher.h"
#include<string>
#include<iostream>
using namespace std;

Teacher::Teacher(string name, int age) :m_strName(name), m_iAge(age)
{
	cout << "Teacher(string name, int age)" << endl;
}
Teacher::Teacher(const Teacher &t)
{
	cout << "Teacher(const Teacher &t)" << endl;
}
Teacher::~Teacher()
{
	cout << "~Teacher()" << endl;//����д����������������
}
void Teacher::SetName(string name)
{
	m_strName = name;
}
string Teacher::GetName()
{
	return m_strName;
}
void Teacher::SetAge(int age)
{
	m_iAge = age;
}
int Teacher::GetAge()
{
	return m_iAge;
}