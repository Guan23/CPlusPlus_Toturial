#include "Coordinate.h"
#include<iostream>
using namespace std;

Coordinate::Coordinate(int X, int Y):m_iX(X), m_iY(Y)
{
	//cout << "Coordinate(int X, int Y)" << endl;
}

Coordinate::~Coordinate()
{
	//cout << "~Coordinate()" << endl;
}
