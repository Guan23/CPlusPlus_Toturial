#pragma once
class Coordinate
{
public:
	int m_iX;
	int m_iY;
public:
	Coordinate(int X = 0, int Y = 0);
	~Coordinate();
};