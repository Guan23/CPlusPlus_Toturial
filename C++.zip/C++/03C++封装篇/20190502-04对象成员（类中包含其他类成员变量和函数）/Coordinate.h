#pragma once
class Coordinate
{
public:
	Coordinate(int x = 0, int y = 0);
	~Coordinate();
	void SetX(int x);
	int GetX();
	void SetY(int y);
	int GetY();
private:
	int m_iX;
	int m_iY;
};

