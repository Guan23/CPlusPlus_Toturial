#include<iostream>
#include<string>
#include"Coordinate.h"
#include"Line.h"

using namespace std;

#define ENTER cout<<endl<<endl

int main()
{
	Line L1(0, 0, 2, 2);
	L1.PrintInfo();
	//system("pause");
	return 0;
}