#pragma once
class Array
{
public:
	Array(int arr = 6);
	Array(const Array &ar);
	~Array();
	void Set_iCount(int count);
	int Get_Count();
	void Print_Addr();
	int *Get_p();
private:
	int m_iCount;		//���鳤��
	int *m_ip;		//����ָ��
};

