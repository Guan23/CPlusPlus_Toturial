#include "Coordinate.h"
#include<iostream>
using namespace std;

Coordinate::Coordinate(int x, int y) :m_iX(x), m_iY(y)
{
	cout << "����Coordinate���캯��" << endl;
}

Coordinate::~Coordinate()
{
	cout << "����Coordinate��������" << endl;
}

void Coordinate::SetX(int x)
{
	
	m_iX = x;
}

int Coordinate::GetX()
{
	return m_iX;
}

void Coordinate::SetY(int y)
{
	m_iY = y;
}

int Coordinate::GetY()
{
	return m_iY;
}
