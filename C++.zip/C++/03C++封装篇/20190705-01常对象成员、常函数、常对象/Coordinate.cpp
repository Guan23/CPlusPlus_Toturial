#include "Coordinate.h"
#include<iostream>
using namespace std;

Coordinate::Coordinate(int x, int y) :M_iX(x), M_iY(y)
{
	//cout << "���ù��캯��" << endl;
}


Coordinate::~Coordinate()
{
	//cout << "X=" << M_iX << ",Y=" << M_iY << endl;
}


int Coordinate::Get_X() const
{
	return M_iX;
}


void Coordinate::Set_X(int x)
{
	M_iX = x;
}


int Coordinate::Get_Y() const
{
	return M_iY;
}


void Coordinate::Set_Y(int y)
{
	M_iY = y;
}


void Coordinate::Print_Coor()
{
	cout << "X=" << M_iX << ",Y=" << M_iY << endl;
}