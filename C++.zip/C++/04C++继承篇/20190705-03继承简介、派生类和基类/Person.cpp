#include "Person.h"
#include<iostream>
#include<string>
using namespace std;

Person::Person(string str, int age, char sex, int height) :m_strName(str), m_iAge(age), m_chSex(sex), m_iHeight(height)
{
	cout << "Person()" << endl;
}

Person::~Person()
{
	cout << "~Person()" << endl;
}

void Person::Eat()
{
	cout << "Eat()" << endl;
}

Person& Person::Set_Sex(char c)
{
	m_chSex = c;
	return *this;
}

char Person::Get_Sex()
{
	return m_chSex;
}

Person& Person::Set_Height(int height)
{
	m_iHeight = height;
	return *this;
}

int Person::Get_Height()
{
	return m_iHeight;
}