#include "Infantry.h"
#include<iostream>
using namespace std;

void Infantry::Attack()
{
	cout << "void Infantry::Attack()" << endl;
}