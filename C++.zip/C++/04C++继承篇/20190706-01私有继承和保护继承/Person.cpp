#include "Person.h"
#include<iostream>
using namespace std;


Person::Person()
{
	m_strName = "Merry";
}


void Person::Play()
{
	cout << "--Play()" << endl;
	cout << m_strName << endl;

}

