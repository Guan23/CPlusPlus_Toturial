#include "Soldier.h"
#include<iostream>
using namespace std;


Soldier::Soldier()
{
}


void Soldier::Work()
{
	m_strName = "Jim";
	m_iAge = 20;
	cout << m_strName << endl;
	cout << m_iAge << endl;
	cout << "void Soldier::Work()" << endl;
}
