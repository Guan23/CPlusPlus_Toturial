#include "Person.h"
#include<iostream>
using namespace std;

Person::Person()
{
}


Person::~Person()
{
}


void Person::Play(int a)
{
	cout << "����ˮ�� a = " << a << endl;
}
