#pragma once
class Person
{
public:
	Person();
	~Person();
	void Play(int a = 0);
protected:
	int m_iCode;
	int age;
};

