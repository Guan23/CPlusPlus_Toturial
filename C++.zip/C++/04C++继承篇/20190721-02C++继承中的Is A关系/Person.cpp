#include "Person.h"
#include<iostream>
using namespace std;


Person::Person(string name)
{
	cout << "Person�Ĺ��캯��" << endl;
	m_strName = name;
}


Person::~Person()
{
	cout << "Person����������" << endl;
}


void Person::Play()
{
	cout << m_strName << endl;
	cout << "Person--Play()" << endl;
}
