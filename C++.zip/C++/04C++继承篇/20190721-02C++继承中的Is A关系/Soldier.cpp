#include "Soldier.h"
#include<iostream>
using namespace std;

Soldier::Soldier(string name, int age)
{
	cout << "Soldier�Ĺ��캯��" << endl;
	m_strName = name;
	m_iAge = age;
}


Soldier::~Soldier()
{
	cout << "Soldier����������" << endl;
}


void Soldier::Work()
{
	cout << m_strName << endl << m_iAge << endl;
	cout << "Soldier--Work()" << endl;
}
