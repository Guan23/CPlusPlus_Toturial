#include "Infantry.h"
#include<iostream>
using namespace std;

Infantry::Infantry(string name, int age)
{
	m_iAge = age;
	m_strName = name;
	cout << "Infantry�Ĺ��캯��" << endl;
}

Infantry::~Infantry()
{
	cout << "Infantry����������" << endl;
}

void Infantry::Attack()
{
	cout << m_strName << endl;
	cout << m_iAge << endl;
	cout << "--Attack()" << endl;
}