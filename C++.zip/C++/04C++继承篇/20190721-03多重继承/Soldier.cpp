#include "Soldier.h"
#include<iostream>
#include<string>

using namespace std;


Soldier::Soldier(string name, int age)
{
	cout << "Soldier�Ĺ��캯��" << endl;
	m_strName = name;
	m_iAge = age;
}


Soldier::~Soldier()
{
	cout << "Soldier����������" << endl;
}


void Soldier::Work()
{
	cout << m_strName << endl;
	cout << m_iAge << endl;
	cout << "--Work()" << endl;
}
