#pragma once
#include<string>
using namespace std;

class Farmer
{
public:
	Farmer(string name = "ũ��");
	virtual ~Farmer();
	void Sow();
protected:
	string m_strName;
};

