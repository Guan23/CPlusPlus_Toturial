#pragma once
#include<string>
using namespace std;

class Worker
{
public:
	Worker(string code = "01");
	virtual ~Worker();
	void Carry();
protected:
	string m_strCode;
};

