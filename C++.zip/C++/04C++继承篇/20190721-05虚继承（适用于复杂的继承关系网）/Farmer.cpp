#include "Farmer.h"
#include<iostream>
#include<string>
using namespace std;

Farmer::Farmer(string name, string color) :Person(color)
{
	m_strName = name;
	cout << "ũ��Ĺ��캯��" << endl;
}


Farmer::~Farmer()
{
	cout << "ũ�����������" << endl;
}

void Farmer::Sow()
{
	cout << m_strName << endl;
	cout << "Sow()" << endl;
}
