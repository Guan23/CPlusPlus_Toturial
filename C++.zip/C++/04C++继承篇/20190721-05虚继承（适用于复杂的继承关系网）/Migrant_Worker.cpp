#include "Migrant_Worker.h"
#include<iostream>
using namespace std;

Migrant_Worker::Migrant_Worker(string code, string name, string color) :Worker(code, color), Farmer(name, color)
{
	cout << "ũ�񹤵Ĺ��캯��" << endl;
}


Migrant_Worker::~Migrant_Worker()
{
	cout << "ũ�񹤵���������" << endl;
}
