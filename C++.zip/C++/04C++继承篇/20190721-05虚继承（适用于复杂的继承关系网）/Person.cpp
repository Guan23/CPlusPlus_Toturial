#include "Person.h"
#include<iostream>
#include<string>
using namespace std;

Person::Person(string color)
{
	m_strColor = color;
	cout << "�˵Ĺ��캯��" << endl;
}


Person::~Person()
{
	cout << "�˵���������" << endl;
}


void Person::Print_Color()
{
	cout << m_strColor << endl;
	cout << "Print_Color()" << endl;
}