#pragma once
#ifndef PERSON_H
#define PERSON_H

#include<string>
using namespace std;

class Person
{
public:
	Person(string color = "Red");
	virtual ~Person();
	void Print_Color();
protected:
	string m_strColor;
};

#endif
