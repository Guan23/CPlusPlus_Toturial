#pragma once
#ifndef WORKER_H
#define WORKER_H

#include<string>
#include"Person.h"
using namespace std;

class Worker :  virtual public Person
{
public:
	Worker(string code = "001", string color = "Red");
	virtual ~Worker();
	void Carry();
protected:
	string m_strCode;
};

#endif

