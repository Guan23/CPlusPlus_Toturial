#include "Circle.h"
#include<iostream>
using namespace std;

Circle::Circle(double radius)
{
	m_dRadius = radius;
	cout << "Circle�Ĺ��캯��" << endl;
}


Circle::~Circle()
{
	cout << "Circle�Ĺ��캯��" << endl;
}


double Circle::Calc_Area()
{
	//cout << "Circle--Area()" << endl;
	return 3.14*m_dRadius*m_dRadius;
}