#include "Rect.h"
#include<iostream>
using namespace std;

Rect::Rect(double width, double length)
{
	m_dWidth = width;
	m_dLength = length;
	cout << "Rect�Ĺ��캯��" << endl;
}


Rect::~Rect()
{
	cout << "Rect�Ĺ��캯��" << endl;
}


double Rect::Calc_Area()
{
	cout << "Rect--Area()" << endl;
	return m_dWidth*m_dLength;
}
