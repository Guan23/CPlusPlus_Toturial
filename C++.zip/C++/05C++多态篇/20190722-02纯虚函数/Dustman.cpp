#include "Dustman.h"
#include<iostream>
using namespace std;

Dustman::Dustman(string name, int age) :Worker(name, age)
{
}

Dustman::~Dustman()
{
}

void Dustman::Work()
{
	cout << m_strName << "\t" << m_iAge << endl;
	cout << "ɨ��" << endl;
}