#include "Person.h"


Person::Person(string name)
{
	m_strName = name;
}


Person::~Person()
{

}
