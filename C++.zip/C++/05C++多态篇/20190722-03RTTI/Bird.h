#pragma once
#ifndef BIRD_H
#define BIRD_H
#include"Flyable.h"

class Bird : public Flyable
{
public:
	void foraging();
	virtual void Takeoff();
	virtual void Land();
};

#endif