#pragma once
#ifndef FLYABLE_H
#define FLYABLE_H

class Flyable
{
public:
	virtual void Takeoff() = 0;
	virtual void Land() = 0;
};

#endif