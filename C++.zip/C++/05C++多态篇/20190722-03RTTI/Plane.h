#pragma once
#ifndef PLANE_H
#define PLANE_H

#include "Flyable.h"

class Plane :
	public Flyable
{
public:
	void Carry();
	virtual void Takeoff();
	virtual void Land();
};

#endif