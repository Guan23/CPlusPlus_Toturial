#include "Exception.h"
#include<iostream>
using namespace std;

void Exception::Print_Exception()
{
	cout << "�쳣" << endl;
}

