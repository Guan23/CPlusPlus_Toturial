#pragma once

#ifndef EXCEPTION_H
#define EXCEPTION_H
class Exception
{
public:

	virtual void Question() = 0;
};

#endif