#include "IndexException.h"
#include<iostream>
using namespace std;

IndexException::IndexException()
{
}


IndexException::~IndexException()
{
}


void IndexException::Question()
{
	cout << "����Խ��" << endl;
}