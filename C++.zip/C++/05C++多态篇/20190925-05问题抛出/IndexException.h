#pragma once

#ifndef INDEX_EXCEPTION_H
#define INDEX_EXCEPTION_H

#include "Exception.h"
class IndexException :
	public Exception
{
public:
	IndexException();
	~IndexException();
	virtual void Question();
};

#endif
