#include<iostream>
#include"IndexException.h"
using namespace std;

void test1()
{
	//throw "ABC";
}

void test2()
{
	throw IndexException();
}

int main()
{
	try
	{
		test1();
	}
	catch (int &a)
	{

		cout << a << endl;
	}
	catch (double &b)
	{
		cout << b << endl;
	}
	catch (...)
	{
		cout << "�ػ���" << endl;
	}

	try
	{
		test2();
	}
	catch (Exception &s)
	{
		s.Question();
	}

	catch (...)
	{
		cout << "�ػ���" << endl;
	}


	system("pause");
	return 0;
}