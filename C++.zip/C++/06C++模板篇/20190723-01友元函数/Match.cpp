#include "Match.h"
#include"Time.h"
#include<iostream>

using namespace std;

void Match::PrintTime(Time &t)
{
	//cout << t.m_iHour << ":" << t.m_iMinute << ":" << t.m_iSecond << endl;
}

void Match::TestTime()
{
	m_tTime.PrintTime();
	cout << m_tTime.m_iHour << "-" << m_tTime.m_iMinute << "-" << m_tTime.m_iSecond << endl;
}
