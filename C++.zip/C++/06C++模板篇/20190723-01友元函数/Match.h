#pragma once

#ifndef STUDENT_H
#define STUDENT_H
#include"Time.h"

class Time;
class Match
{
	friend Time;
public:
	void PrintTime(Time &t);
	void TestTime();
private:
	Time m_tTime;


};

#endif